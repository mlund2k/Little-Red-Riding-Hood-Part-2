#ifndef STREAMREADER_H
#define STREAMREADER_H

class StreamReader {
public:
  StreamReader();
};

#endif // STREAMREADER_H